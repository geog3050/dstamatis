from pyeto import thornthwaite, monthly_mean_daylight_hours, deg2rad
lat = deg2rad(37.69)  # Convert latitude in degrees to radians
# Calculate mean daylight hours of each month
mmdlh = monthly_mean_daylight_hours(lat, 2023)
mmdlh
# Create iterable of monthly mean temperatures in degrees Celsius
monthly_t = [4.3,6.7,7.7,14.1,19.5,23.8,25.7,24.5,21.1,14.9,8.7,6.1]
thornthwaite(monthly_t, mmdlh)   # Calculate PET




